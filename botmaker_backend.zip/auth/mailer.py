def send_otp(email: str, otp: str):
    print(f"Sending OTP {otp} to {email}")  # Replace with real email logic