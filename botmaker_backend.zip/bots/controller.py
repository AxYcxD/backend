async def upload_bot(data):
    return {"msg": "Uploaded (dummy response)"}

async def start_bot(data):
    return {"msg": "Bot started (dummy response)"}

async def stop_bot(data):
    return {"msg": "Bot stopped (dummy response)"}

async def restart_bot(data):
    return {"msg": "Bot restarted (dummy response)"}